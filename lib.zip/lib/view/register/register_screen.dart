import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:vivahbharath_app/view/custom/app_colors.dart';
import 'package:vivahbharath_app/view/custom/responsive.dart';
import 'package:vivahbharath_app/view/register/verify_otp_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  String? _profileFor = 'Myself';
  String? _motherTongue = 'Malayalam';

  static const _profileOptions = [
    'Myself',
    'Son',
    'Daughter',
    'Brother',
    'Sister',
    'Relative',
    'Friend',
  ];
  static const _languages = [
    'Malayalam',
    'Tamil',
    'Telugu',
    'Kannada',
    'Hindi',
    'Marathi',
    'Bengali',
    'Gujarati',
    'Punjabi',
    'English',
  ];

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    super.dispose();
  }

  void _onProceed() {
    FocusScope.of(context).unfocus();
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => VerifyCodeScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    // Hero, form and buttons scroll together, so nothing overflows on short
    // screens, in landscape or with the keyboard open. When there's spare
    // height the buttons still sit at the bottom of the screen.
    final side = contentSidePadding(context);
    return Scaffold(
      backgroundColor: AppColors.cream,
      body: CustomScrollView(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        slivers: [
          const SliverToBoxAdapter(child: _Hero()),
          SliverFillRemaining(
            hasScrollBody: false,
            child: SafeArea(
              top: false,
              child: Padding(
                padding: EdgeInsets.fromLTRB(24 + side, 28, 24 + side, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Register',
                      style: GoogleFonts.fraunces(
                        fontSize: 28,
                        fontWeight: FontWeight.w700,
                        color: AppColors.headline,
                        height: 1.1,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      "Let's get started. Tell us a little about the "
                      "profile you're creating.",
                      style: GoogleFonts.dmSans(
                        fontSize: 16,
                        height: 1.5,
                        color: AppColors.body,
                      ),
                    ),
                    const SizedBox(height: 28),
                    const _Label("Bride's/Groom's Name"),
                    _Field(
                      controller: _nameCtrl,
                      hint: 'Full name',
                      textCapitalization: TextCapitalization.words,
                    ),
                    const SizedBox(height: 20),
                    const _Label('Create Profile For'),
                    _Dropdown(
                      value: _profileFor,
                      items: _profileOptions,
                      onChanged: (v) => setState(() => _profileFor = v),
                    ),
                    const SizedBox(height: 20),
                    const _Label('Mother Tongue'),
                    _Dropdown(
                      value: _motherTongue,
                      items: _languages,
                      onChanged: (v) => setState(() => _motherTongue = v),
                    ),
                    const SizedBox(height: 20),
                    const _Label('Phone Number'),
                    _PhoneField(controller: _phoneCtrl),
                    const Spacer(),
                    const SizedBox(height: 24),
                    _PrimaryButton(label: 'Proceed', onTap: _onProceed),
                    const SizedBox(height: 14),
                    // full width, so WrapAlignment.center can centre it
                    SizedBox(
                      width: double.infinity,
                      child: Wrap(
                        alignment: WrapAlignment.center,
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: [
                          Text(
                            'Already a member? ',
                            style: GoogleFonts.dmSans(
                              fontSize: 15,
                              color: AppColors.body,
                            ),
                          ),
                          GestureDetector(
                            onTap: () => Navigator.maybePop(context),
                            child: Text(
                              'Login',
                              style: GoogleFonts.dmSans(
                                fontSize: 15,
                                fontWeight: FontWeight.w700,
                                color: AppColors.link,
                                decoration: TextDecoration.underline,
                                decorationColor: AppColors.link,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/* ───────────────────────── HERO ───────────────────────── */

class _Hero extends StatelessWidget {
  const _Hero();

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final top = mq.padding.top;
    // 215 on a typical phone; shorter in landscape, a bit taller on tablets.
    final h = (mq.size.height * 0.255).clamp(150.0, 260.0);
    final k = h / 215;
    return ClipPath(
      clipper: _WaveClipper(),
      child: Container(
        height: h + top,
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [AppColors.tealA, AppColors.tealB, AppColors.tealC],
          ),
        ),
        child: Stack(
          children: [
            // soft glow top-right
            Positioned(
              right: -40,
              top: top + 10 * k,
              child: Container(
                width: 220 * k,
                height: 220 * k,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [AppColors.glow, AppColors.glowEnd],
                  ),
                ),
              ),
            ),
            // hearts
            Positioned(
              top: top + 66 * k,
              left: 0,
              right: 0,
              child: Center(
                child: Image.asset(
                  'assets/images/hearts_illustration_transparent.png',
                  width: 156 * k,
                ),
              ),
            ),
            // thread
            // Positioned(
            //   top: top + 68,
            //   left: 0,
            //   right: 0,
            //   child: Center(
            //     child: Image.asset(
            //       'assets/images/part-thread.png',
            //       width: 180,
            //     ),
            //   ),
            // ),
            // logo
            Positioned(
              top: top + 14 * k,
              left: 0,
              right: 0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // const Icon(Icons.format_line_spacing,
                  //     size: 0), // placeholder to keep Row baseline
                  // Transform.rotate(
                  //   angle: 0.8,
                  //   child: Column(
                  //     children: List.generate(
                  //       4,
                  //       (_) => Container(
                  //         width: 22,
                  //         height: 2,
                  //         margin: const EdgeInsets.symmetric(vertical: 1.5),
                  //         color: AppColors.sparkleGold,
                  //       ),
                  //     ),
                  //   ),
                  // ),
                  // const SizedBox(width: 10),
                  Image.asset(
                    'assets/images/logo-mark-gold@3x.png',
                    height: 25 * k,
                  ),
                  const SizedBox(width: 5),
                  Flexible(
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(
                        'vivahbharath',
                        style: GoogleFonts.fraunces(
                          fontSize: 26,
                          fontWeight: FontWeight.w600,
                          color: AppColors.sparkleGold,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // step dots
            // Positioned(
            //   top: top + 58,
            //   left: 0,
            //   right: 0,
            //   child: Row(
            //     mainAxisAlignment: MainAxisAlignment.center,
            //     children: [
            //       _dot(26, AppColors.sparkleGold),
            //       const SizedBox(width: 6),
            //       _dot(8, Colors.white38),
            //       const SizedBox(width: 6),
            //       _dot(8, Colors.white38),
            //     ],
            //   ),
            // ),
            // back button
            // Positioned(
            //   top: top + 8,
            //   left: 18,
            //   child: GestureDetector(
            //     onTap: () => Navigator.maybePop(context),
            //     child: Container(
            //       width: 46,
            //       height: 46,
            //       decoration: BoxDecoration(
            //         shape: BoxShape.circle,
            //         color: Colors.white.withOpacity(0.16),
            //         border: Border.all(color: Colors.white38),
            //       ),
            //       child: const Icon(Icons.chevron_left,
            //           color: Colors.white, size: 28),
            //     ),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }

  Widget _dot(double w, Color c) => Container(
    width: w,
    height: 8,
    decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(8)),
  );
}

class _WaveClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final p = Path()..lineTo(0, size.height - 22);
    p.cubicTo(
      size.width * 0.18,
      size.height - 40,
      size.width * 0.38,
      size.height - 6,
      size.width * 0.58,
      size.height - 14,
    );
    p.cubicTo(
      size.width * 0.78,
      size.height - 22,
      size.width * 0.9,
      size.height - 44,
      size.width,
      size.height - 34,
    );
    p.lineTo(size.width, 0);
    p.close();
    return p;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> old) => false;
}

/* ───────────────────────── FORM PARTS ───────────────────────── */

class _Label extends StatelessWidget {
  final String text;
  const _Label(this.text);

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text.rich(
      TextSpan(
        text: text,
        children: const [
          TextSpan(
            text: ' *',
            style: TextStyle(color: Colors.red),
          ),
        ],
      ),
      style: GoogleFonts.dmSans(
        fontSize: 15,
        fontWeight: FontWeight.w600,
        color: AppColors.body,
      ),
    ),
  );
}

BoxDecoration _fieldBox() => BoxDecoration(
  color: Colors.white,
  borderRadius: BorderRadius.circular(18),
  border: Border.all(color: AppColors.fieldBorder, width: 1.5),
);

class _Field extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final TextCapitalization textCapitalization;
  const _Field({
    required this.controller,
    required this.hint,
    this.textCapitalization = TextCapitalization.none,
  });

  @override
  Widget build(BuildContext context) => Container(
    constraints: const BoxConstraints(minHeight: 56),
    alignment: Alignment.center,
    padding: const EdgeInsets.symmetric(horizontal: 18),
    decoration: _fieldBox(),
    child: TextField(
      controller: controller,
      textCapitalization: textCapitalization,
      style: GoogleFonts.dmSans(fontSize: 17, color: AppColors.headline),
      decoration: InputDecoration(
        border: InputBorder.none,
        hintText: hint,
        hintStyle: GoogleFonts.dmSans(fontSize: 17, color: AppColors.hint),
      ),
    ),
  );
}

class _Dropdown extends StatelessWidget {
  final String? value;
  final List<String> items;
  final ValueChanged<String?> onChanged;
  const _Dropdown({
    required this.value,
    required this.items,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) => Container(
    constraints: const BoxConstraints(minHeight: 56),
    alignment: Alignment.center,
    padding: const EdgeInsets.symmetric(horizontal: 18),
    decoration: _fieldBox(),
    child: DropdownButtonHideUnderline(
      child: DropdownButton<String>(
        value: value,
        isExpanded: true,
        borderRadius: BorderRadius.circular(16),
        dropdownColor: Colors.white,
        icon: const Icon(
          Icons.keyboard_arrow_down_rounded,
          color: AppColors.body,
        ),
        style: GoogleFonts.dmSans(fontSize: 17, color: AppColors.headline),
        items: items
            .map((e) => DropdownMenuItem(value: e, child: Text(e)))
            .toList(),
        onChanged: onChanged,
      ),
    ),
  );
}

class _PhoneField extends StatelessWidget {
  final TextEditingController controller;
  const _PhoneField({required this.controller});

  @override
  Widget build(BuildContext context) => Container(
    constraints: const BoxConstraints(minHeight: 56),
    alignment: Alignment.center,
    padding: const EdgeInsets.symmetric(horizontal: 18),
    decoration: _fieldBox(),
    child: Row(
      children: [
        Text(
          '+91',
          style: GoogleFonts.dmSans(
            fontSize: 17,
            fontWeight: FontWeight.w700,
            color: AppColors.headline,
          ),
        ),
        Container(
          width: 1.5,
          height: 26,
          margin: const EdgeInsets.symmetric(horizontal: 14),
          color: AppColors.fieldBorder,
        ),
        Expanded(
          child: TextField(
            controller: controller,
            keyboardType: TextInputType.phone,
            maxLength: 10,
            style: GoogleFonts.dmSans(fontSize: 17, color: AppColors.headline),
            decoration: InputDecoration(
              border: InputBorder.none,
              counterText: '',
              hintText: '10-digit mobile number',
              hintStyle: GoogleFonts.dmSans(
                fontSize: 17,
                color: AppColors.hint,
              ),
            ),
          ),
        ),
      ],
    ),
  );
}

class _PrimaryButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _PrimaryButton({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      height: 62,
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(31),
        gradient: const LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [AppColors.btnA, AppColors.tealC],
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.tealC.withOpacity(0.28),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            label,
            style: GoogleFonts.dmSans(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
          const SizedBox(width: 12),
          const Icon(
            Icons.arrow_forward_rounded,
            color: AppColors.sparkleGold,
            size: 24,
          ),
        ],
      ),
    ),
  );
}
