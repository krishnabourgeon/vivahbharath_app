import 'package:flutter/material.dart';
import 'package:vivahbharath_app/view/register/personal_physical_screen.dart';
import 'package:vivahbharath_app/view/register/sign_up_data.dart';
import 'package:vivahbharath_app/view/register/sign_up_options.dart';
import 'package:vivahbharath_app/view/register/sign_up_widget.dart';

class ProfessionalDetailsScreen extends StatefulWidget {
  const ProfessionalDetailsScreen({super.key, required this.data});

  final SignUpData data;

  @override
  State<ProfessionalDetailsScreen> createState() =>
      _ProfessionalDetailsScreenState();
}

class _ProfessionalDetailsScreenState
    extends State<ProfessionalDetailsScreen> {
  SignUpData get d => widget.data;

  late final _eduDetailCtrl =
      TextEditingController(text: d.educationDetail);

  @override
  void dispose() {
    _eduDetailCtrl.dispose();
    super.dispose();
  }

  void _toggleLanguage(String lang) => setState(() =>
      d.languages.contains(lang) ? d.languages.remove(lang) : d.languages.add(lang));

  void _onContinue() {
    FocusScope.of(context).unfocus();
    d.educationDetail = _eduDetailCtrl.text.trim();
    // TODO: validate required fields
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => PersonalPhysicalScreen(data: d)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SignUpScaffold(
      step: 3,
      title: 'Professional details',
      subtitle: 'Your education, work and income.',
      primaryLabel: 'Continue',
      onPrimary: _onContinue,
      note: 'You can edit all of this later from your dashboard.',
      children: [
        FormCard(title: 'Education', children: [
          DropdownField(
            label: 'Highest education',
            required: true,
            value: d.education,
            items: SignUpOptions.educations,
            onChanged: (v) => setState(() => d.education = v),
          ),
          LabeledField(
            label: 'Education in detail',
            child: AppTextInput(
              controller: _eduDetailCtrl,
              hint: 'e.g. B.Tech in Computer Science, NIT Calicut',
              maxLines: 3,
              maxLength: 255,
            ),
          ),
          LabeledField(
            label: 'Languages known',
            child: ChoiceChips(
              options: SignUpOptions.languages,
              isSelected: d.languages.contains,
              onTap: _toggleLanguage,
            ),
          ),
        ]),
        FormCard(title: 'Work', children: [
          LabeledField(
            label: 'Employment type',
            child: ChoiceChips(
              options: SignUpOptions.employmentTypes,
              isSelected: (o) => o == d.employmentType,
              onTap: (o) => setState(() => d.employmentType = o),
            ),
          ),
          DropdownField(
            label: 'Occupation',
            required: true,
            value: d.occupation,
            items: SignUpOptions.occupations,
            onChanged: (v) => setState(() => d.occupation = v),
          ),
          TwoColumn(
            left: DropdownField(
              label: 'Working country',
              value: d.workCountry,
              items: SignUpOptions.countries,
              onChanged: (v) => setState(() => d.workCountry = v),
            ),
            right: DropdownField(
              label: 'Working state',
              value: d.workState,
              items: SignUpOptions.states,
              onChanged: (v) => setState(() => d.workState = v),
            ),
          ),
          TwoColumn(
            left: DropdownField(
              label: 'Working city',
              value: d.workCity,
              items: SignUpOptions.cities,
              onChanged: (v) => setState(() => d.workCity = v),
            ),
            right: DropdownField(
              label: 'Residential status',
              value: d.residentialStatus,
              items: SignUpOptions.residentialStatuses,
              onChanged: (v) => setState(() => d.residentialStatus = v),
            ),
          ),
        ]),
        FormCard(title: 'Annual income', children: [
          Row(
            children: [
              Expanded(
                flex: 2,
                child: DropdownField(
                  value: d.currency,
                  items: SignUpOptions.currencies,
                  onChanged: (v) => setState(() => d.currency = v!),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                flex: 4,
                child: DropdownField(
                  value: d.income,
                  items: SignUpOptions.incomeRanges,
                  onChanged: (v) => setState(() => d.income = v),
                ),
              ),
            ],
          ),
        ]),
      ],
    );
  }
}