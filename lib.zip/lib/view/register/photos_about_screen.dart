import 'package:flutter/material.dart';
import 'package:vivahbharath_app/view/custom/app_colors.dart';
import 'package:vivahbharath_app/view/register/family_details_screen.dart';
import 'package:vivahbharath_app/view/register/sign_up_data.dart';
import 'package:vivahbharath_app/view/register/sign_up_options.dart';
import 'package:vivahbharath_app/view/register/sign_up_widget.dart';

class PhotosAboutScreen extends StatefulWidget {
  const PhotosAboutScreen({super.key, required this.data});

  final SignUpData data;

  @override
  State<PhotosAboutScreen> createState() => _PhotosAboutScreenState();
}

class _PhotosAboutScreenState extends State<PhotosAboutScreen> {
  SignUpData get d => widget.data;

  late final _aboutCtrl = TextEditingController(text: d.aboutMe);

  @override
  void dispose() {
    _aboutCtrl.dispose();
    super.dispose();
  }

  void _pickPhoto(int index) {
    // TODO: pick an image (e.g. with image_picker), then:
    // setState(() => d.photos[index] = FileImage(file));
  }

  void _save() => d.aboutMe = _aboutCtrl.text.trim();

  void _onSubmitNow() {
    _save();
    // TODO: save the partial profile (widget.data) and leave the flow
  }

  void _onContinue() {
    FocusScope.of(context).unfocus();
    _save();
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => FamilyDetailsScreen(data: d)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SignUpScaffold(
      step: 5,
      title: 'Photos & about you',
      subtitle: 'Add photos and a few lines about yourself.',
      primaryLabel: 'Continue',
      onPrimary: _onContinue,
      secondaryLabel: 'Submit now',
      onSecondary: _onSubmitNow,
      note: 'Profiles with photos get far more responses.',
      children: [
        FormCard(
          title: 'Upload photos',
          subtitle:
              'A clear, medium close-up works best as your profile photo.',
          children: [
            LayoutBuilder(
              builder: (context, c) => GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                padding: EdgeInsets.zero,
                itemCount: SignUpOptions.photoLabels.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  // 3 per row on very narrow cards so labels stay readable
                  crossAxisCount: c.maxWidth < 280 ? 3 : 4,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  childAspectRatio: 0.75,
                ),
                itemBuilder: (_, i) => _PhotoSlot(
                  label: SignUpOptions.photoLabels[i],
                  image: d.photos[i],
                  isProfile: i == 0,
                  onTap: () => _pickPhoto(i),
                  onRemove: () => setState(() => d.photos[i] = null),
                ),
              ),
            ),
            const SizedBox(height: 16),
            const InfoBox(
              icon: Icons.shield_outlined,
              text: 'Photos are watermarked and you control who can see them.',
            ),
            const SizedBox(height: 20),
          ],
        ),
        FormCard(title: 'About me', children: [
          LabeledField(
            child: AppTextInput(
              controller: _aboutCtrl,
              hint: 'Write a few lines about yourself',
              maxLines: 4,
              maxLength: 255,
            ),
          ),
        ]),
      ],
    );
  }
}

class _PhotoSlot extends StatelessWidget {
  const _PhotoSlot({
    required this.label,
    required this.image,
    required this.isProfile,
    required this.onTap,
    required this.onRemove,
  });

  final String label;
  final ImageProvider? image;
  final bool isProfile;
  final VoidCallback onTap;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    if (image != null) {
      return Stack(
        fit: StackFit.expand,
        children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.tealB, width: 3),
              image: DecorationImage(image: image!, fit: BoxFit.cover),
            ),
          ),
          Positioned(
            top: 4,
            right: 4,
            child: GestureDetector(
              onTap: onRemove,
              child: Container(
                width: 26,
                height: 26,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFFC0392B),
                  border: Border.all(color: Colors.white, width: 2),
                ),
                child: const Icon(Icons.close_rounded,
                    color: Colors.white, size: 16),
              ),
            ),
          ),
          if (isProfile)
            Positioned(
              left: 6,
              bottom: 6,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: AppColors.tealC,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text('Profile',
                    style: dmText(12, w: FontWeight.w700, c: Colors.white)),
              ),
            ),
        ],
      );
    }

    return GestureDetector(
      onTap: onTap,
      child: CustomPaint(
        foregroundPainter: _DashedBorderPainter(),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFFFFFCF7), Color(0xFFF8EBDD)],
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                  border: Border.all(color: AppColors.loginBorder),
                ),
                child: const Icon(Icons.add_rounded,
                    color: AppColors.loginText, size: 18),
              ),
              const SizedBox(height: 8),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(label,
                      style: dmText(13,
                          w: FontWeight.w700, c: AppColors.loginText)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DashedBorderPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppColors.loginBorder
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    final path = Path()
      ..addRRect(RRect.fromRectAndRadius(
          Offset.zero & size, const Radius.circular(16)));
    for (final metric in path.computeMetrics()) {
      for (double dist = 0; dist < metric.length; dist += 9) {
        canvas.drawPath(metric.extractPath(dist, dist + 5), paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}