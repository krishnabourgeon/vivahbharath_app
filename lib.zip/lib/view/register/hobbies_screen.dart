import 'package:flutter/material.dart';
import 'package:vivahbharath_app/view/register/sign_up_data.dart';
import 'package:vivahbharath_app/view/register/sign_up_options.dart';
import 'package:vivahbharath_app/view/register/sign_up_widget.dart';

class HobbiesScreen extends StatefulWidget {
  const HobbiesScreen({super.key, required this.data});

  final SignUpData data;

  @override
  State<HobbiesScreen> createState() => _HobbiesScreenState();
}

class _HobbiesScreenState extends State<HobbiesScreen> {
  SignUpData get d => widget.data;

  late final _otherCtrl = TextEditingController(text: d.otherHobbies);

  @override
  void dispose() {
    _otherCtrl.dispose();
    super.dispose();
  }

  void _toggleHobby(String hobby) => setState(() =>
      d.hobbies.contains(hobby) ? d.hobbies.remove(hobby) : d.hobbies.add(hobby));

  void _submit() {
    FocusScope.of(context).unfocus();
    // TODO: submit the full profile (widget.data), then go to the dashboard
  }

  void _onFinish() {
    d.otherHobbies = _otherCtrl.text.trim();
    _submit();
  }

  @override
  Widget build(BuildContext context) {
    return SignUpScaffold(
      step: 7,
      title: 'Hobbies & interests',
      subtitle: 'Shared interests make great conversations.',
      primaryLabel: 'Finish',
      onPrimary: _onFinish,
      secondaryLabel: 'Skip',
      onSecondary: _submit,
      note: 'You can edit all of this later from your dashboard.',
      children: [
        FormCard(title: 'Pick what you enjoy', children: [
          LabeledField(
            child: ChoiceChips(
              options: SignUpOptions.hobbies,
              isSelected: d.hobbies.contains,
              onTap: _toggleHobby,
            ),
          ),
          LabeledField(
            label: 'Anything else?',
            child: AppTextInput(
              controller: _otherCtrl,
              hint: 'Tell us more',
              maxLines: 4,
              maxLength: 255,
            ),
          ),
        ]),
      ],
    );
  }
}