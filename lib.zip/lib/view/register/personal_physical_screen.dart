import 'package:flutter/material.dart';
import 'package:vivahbharath_app/view/register/photos_about_screen.dart';
import 'package:vivahbharath_app/view/register/sign_up_data.dart';
import 'package:vivahbharath_app/view/register/sign_up_options.dart';
import 'package:vivahbharath_app/view/register/sign_up_widget.dart';

class PersonalPhysicalScreen extends StatefulWidget {
  const PersonalPhysicalScreen({super.key, required this.data});

  final SignUpData data;

  @override
  State<PersonalPhysicalScreen> createState() => _PersonalPhysicalScreenState();
}

class _PersonalPhysicalScreenState extends State<PersonalPhysicalScreen> {
  SignUpData get d => widget.data;

  void _onSubmitNow() {
    // TODO: save the partial profile (widget.data) and leave the flow
  }

  void _onContinue() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => PhotosAboutScreen(data: d)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SignUpScaffold(
      step: 4,
      title: 'Personal & physical',
      subtitle: 'A little about you and your lifestyle.',
      primaryLabel: 'Continue',
      onPrimary: _onContinue,
      secondaryLabel: 'Submit now',
      onSecondary: _onSubmitNow,
      note: 'Submit now to finish later, or continue to complete your profile.',
      children: [
        FormCard(title: 'Marital status', children: [
          LabeledField(
            child: ChoiceChips(
              options: SignUpOptions.maritalStatuses,
              isSelected: (o) => o == d.maritalStatus,
              onTap: (o) => setState(() => d.maritalStatus = o),
            ),
          ),
          CounterTile(
            label: 'Number of children',
            value: d.children,
            onChanged: (v) => setState(() => d.children = v),
          ),
        ]),
        FormCard(title: 'Physical details', children: [
          TwoColumn(
            left: DropdownField(
              label: 'Height',
              value: d.height,
              items: SignUpOptions.heights,
              onChanged: (v) => setState(() => d.height = v),
            ),
            right: DropdownField(
              label: 'Weight',
              value: d.weight,
              items: SignUpOptions.weights,
              onChanged: (v) => setState(() => d.weight = v),
            ),
          ),
          TwoColumn(
            left: DropdownField(
              label: 'Body type',
              value: d.bodyType,
              items: SignUpOptions.bodyTypes,
              onChanged: (v) => setState(() => d.bodyType = v),
            ),
            right: DropdownField(
              label: 'Complexion',
              value: d.complexion,
              items: SignUpOptions.complexions,
              onChanged: (v) => setState(() => d.complexion = v),
            ),
          ),
          TwoColumn(
            left: DropdownField(
              label: 'Blood group',
              value: d.bloodGroup,
              items: SignUpOptions.bloodGroups,
              onChanged: (v) => setState(() => d.bloodGroup = v),
            ),
            right: DropdownField(
              label: 'Disability',
              value: d.disability,
              items: SignUpOptions.disabilities,
              onChanged: (v) => setState(() => d.disability = v),
            ),
          ),
          YesNoToggle(
            question: 'Any major surgery or organ transplant?',
            value: d.surgery,
            onChanged: (v) => setState(() => d.surgery = v),
          ),
        ]),
        FormCard(title: 'Lifestyle', children: [
          DropdownField(
            label: 'Diet',
            value: d.diet,
            items: SignUpOptions.diets,
            onChanged: (v) => setState(() => d.diet = v),
          ),
          TwoColumn(
            left: DropdownField(
              label: 'Smoking',
              value: d.smoking,
              items: SignUpOptions.habits,
              onChanged: (v) => setState(() => d.smoking = v),
            ),
            right: DropdownField(
              label: 'Drinking',
              value: d.drinking,
              items: SignUpOptions.habits,
              onChanged: (v) => setState(() => d.drinking = v),
            ),
          ),
          YesNoToggle(
            question: 'Do you have pets?',
            value: d.pets,
            onChanged: (v) => setState(() => d.pets = v),
          ),
        ]),
      ],
    );
  }
}