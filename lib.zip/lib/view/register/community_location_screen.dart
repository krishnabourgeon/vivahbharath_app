import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:vivahbharath_app/view/register/professional_details_screen.dart';
import 'package:vivahbharath_app/view/register/sign_up_data.dart';
import 'package:vivahbharath_app/view/register/sign_up_options.dart';
import 'package:vivahbharath_app/view/register/sign_up_widget.dart';

class CommunityLocationScreen extends StatefulWidget {
  const CommunityLocationScreen({super.key, required this.data});

  final SignUpData data;

  @override
  State<CommunityLocationScreen> createState() =>
      _CommunityLocationScreenState();
}

class _CommunityLocationScreenState extends State<CommunityLocationScreen> {
  SignUpData get d => widget.data;

  late final _pincodeCtrl = TextEditingController(text: d.pincode);
  late final _addressCtrl = TextEditingController(text: d.homeAddress);
  late final _currentCtrl = TextEditingController(text: d.currentAddress);

  @override
  void dispose() {
    _pincodeCtrl.dispose();
    _addressCtrl.dispose();
    _currentCtrl.dispose();
    super.dispose();
  }

  String get _permanentSummary {
    final place = [d.permDistrict, d.permState, d.permCountry]
        .whereType<String>()
        .join(', ');
    final pin = _pincodeCtrl.text.trim();
    return pin.isEmpty ? place : '$place · $pin';
  }

  void _onContinue() {
    FocusScope.of(context).unfocus();
    d.pincode = _pincodeCtrl.text.trim();
    d.homeAddress = _addressCtrl.text.trim();
    d.currentAddress = _currentCtrl.text.trim();
    // TODO: validate required fields
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => ProfessionalDetailsScreen(data: d)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SignUpScaffold(
      step: 2,
      title: 'Community & location',
      subtitle: 'Your community and where you live.',
      primaryLabel: 'Continue',
      onPrimary: _onContinue,
      children: [
        FormCard(title: 'Community', children: [
          TwoColumn(
            left: DropdownField(
              label: 'Religion',
              required: true,
              value: d.religion,
              items: SignUpOptions.religions,
              onChanged: (v) => setState(() => d.religion = v),
            ),
            right: DropdownField(
              label: 'Caste',
              required: true,
              value: d.caste,
              items: SignUpOptions.castes,
              onChanged: (v) => setState(() => d.caste = v),
            ),
          ),
          YesNoToggle(
            question: 'Open to matches from other castes?',
            value: d.openToOtherCastes,
            onChanged: (v) => setState(() => d.openToOtherCastes = v),
          ),
          TwoColumn(
            left: DropdownField(
              label: 'Sub caste',
              value: d.subCaste,
              items: SignUpOptions.subCastes,
              onChanged: (v) => setState(() => d.subCaste = v),
            ),
            right: DropdownField(
              label: 'Gotra',
              value: d.gotra,
              items: SignUpOptions.gotras,
              onChanged: (v) => setState(() => d.gotra = v),
            ),
          ),
        ]),
        FormCard(title: 'Native place', children: [
          DropdownField(
            label: 'Country',
            value: d.nativeCountry,
            items: SignUpOptions.countries,
            onChanged: (v) => setState(() => d.nativeCountry = v),
          ),
          TwoColumn(
            left: DropdownField(
              label: 'State',
              value: d.nativeState,
              items: SignUpOptions.states,
              onChanged: (v) => setState(() => d.nativeState = v),
            ),
            right: DropdownField(
              label: 'District',
              value: d.nativeDistrict,
              items: SignUpOptions.districts,
              onChanged: (v) => setState(() => d.nativeDistrict = v),
            ),
          ),
        ]),
        FormCard(title: 'Permanent residence', required: true, children: [
          TwoColumn(
            left: DropdownField(
              label: 'Country',
              value: d.permCountry,
              items: SignUpOptions.countries,
              onChanged: (v) => setState(() => d.permCountry = v),
            ),
            right: DropdownField(
              label: 'State',
              value: d.permState,
              items: SignUpOptions.states,
              onChanged: (v) => setState(() => d.permState = v),
            ),
          ),
          TwoColumn(
            left: DropdownField(
              label: 'District',
              value: d.permDistrict,
              items: SignUpOptions.districts,
              onChanged: (v) => setState(() => d.permDistrict = v),
            ),
            right: LabeledField(
              label: 'Pincode',
              child: AppTextInput(
                controller: _pincodeCtrl,
                hint: 'Pincode',
                keyboardType: TextInputType.number,
                maxLength: 6,
                counter: false,
                formatters: [FilteringTextInputFormatter.digitsOnly],
                onChanged: (_) => setState(() {}),
              ),
            ),
          ),
          LabeledField(
            label: 'Home address',
            required: true,
            child: AppTextInput(
              controller: _addressCtrl,
              hint: 'House name, street, locality',
              maxLines: 3,
            ),
          ),
        ]),
        FormCard(
          title: 'Current residence',
          trailing: SameAsChip(
            value: d.currentSameAsPermanent,
            onChanged: (v) => setState(() => d.currentSameAsPermanent = v),
          ),
          children: [
            LabeledField(
              child: d.currentSameAsPermanent
                  ? InfoBox(
                      icon: Icons.location_on_outlined,
                      text: _permanentSummary,
                    )
                  : AppTextInput(
                      controller: _currentCtrl,
                      hint: '',
                      maxLines: 3,
                    ),
            ),
          ],
        ),
      ],
    );
  }
}