import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:vivahbharath_app/view/register/hobbies_screen.dart';
import 'package:vivahbharath_app/view/register/sign_up_data.dart';
import 'package:vivahbharath_app/view/register/sign_up_options.dart';
import 'package:vivahbharath_app/view/register/sign_up_widget.dart';

class FamilyDetailsScreen extends StatefulWidget {
  const FamilyDetailsScreen({super.key, required this.data});

  final SignUpData data;

  @override
  State<FamilyDetailsScreen> createState() => _FamilyDetailsScreenState();
}

class _FamilyDetailsScreenState extends State<FamilyDetailsScreen> {
  SignUpData get d => widget.data;

  late final _phoneCtrl = TextEditingController(text: d.secondContact);

  @override
  void dispose() {
    _phoneCtrl.dispose();
    super.dispose();
  }

  void _goNext() {
    FocusScope.of(context).unfocus();
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => HobbiesScreen(data: d)),
    );
  }

  void _onContinue() {
    d.secondContact = _phoneCtrl.text.trim();
    _goNext();
  }

  @override
  Widget build(BuildContext context) {
    return SignUpScaffold(
      step: 6,
      title: 'Family details',
      subtitle: 'Tell matches about your family.',
      primaryLabel: 'Continue',
      onPrimary: _onContinue,
      secondaryLabel: 'Skip',
      onSecondary: _goNext,
      note: 'Next you can add your hobbies and interests.',
      children: [
        FormCard(title: 'Family background', children: [
          TwoColumn(
            left: DropdownField(
              label: 'Family status',
              value: d.familyStatus,
              items: SignUpOptions.familyStatuses,
              onChanged: (v) => setState(() => d.familyStatus = v),
            ),
            right: DropdownField(
              label: 'Family type',
              value: d.familyType,
              items: SignUpOptions.familyTypes,
              onChanged: (v) => setState(() => d.familyType = v),
            ),
          ),
          TwoColumn(
            left: DropdownField(
              label: 'Family values',
              value: d.familyValues,
              items: SignUpOptions.familyValues,
              onChanged: (v) => setState(() => d.familyValues = v),
            ),
            right: DropdownField(
              label: 'Family members',
              value: d.familyMembers,
              items: SignUpOptions.familyMemberCounts,
              onChanged: (v) => setState(() => d.familyMembers = v),
            ),
          ),
        ]),
        FormCard(title: 'Siblings', children: [
          CounterTile(
            label: 'Brothers',
            value: d.brothers,
            onChanged: (v) => setState(() {
              d.brothers = v;
              if (d.brothersMarried > v) d.brothersMarried = v;
            }),
          ),
          CounterTile(
            label: 'Brothers married',
            value: d.brothersMarried,
            max: d.brothers,
            onChanged: (v) => setState(() => d.brothersMarried = v),
          ),
          CounterTile(
            label: 'Sisters',
            value: d.sisters,
            onChanged: (v) => setState(() {
              d.sisters = v;
              if (d.sistersMarried > v) d.sistersMarried = v;
            }),
          ),
          CounterTile(
            label: 'Sisters married',
            value: d.sistersMarried,
            max: d.sisters,
            onChanged: (v) => setState(() => d.sistersMarried = v),
          ),
        ]),
        FormCard(title: 'Parents & contact', children: [
          TwoColumn(
            left: DropdownField(
              label: "Father's occupation",
              value: d.fatherOccupation,
              items: SignUpOptions.parentOccupations,
              onChanged: (v) => setState(() => d.fatherOccupation = v),
            ),
            right: DropdownField(
              label: "Mother's occupation",
              value: d.motherOccupation,
              items: SignUpOptions.parentOccupations,
              onChanged: (v) => setState(() => d.motherOccupation = v),
            ),
          ),
          DropdownField(
            label: 'Family property value',
            value: d.propertyValue,
            items: SignUpOptions.propertyValues,
            onChanged: (v) => setState(() => d.propertyValue = v),
          ),
          LabeledField(
            label: 'Second contact number',
            child: AppTextInput(
              controller: _phoneCtrl,
              hint: '10-digit mobile number',
              keyboardType: TextInputType.phone,
              maxLength: 10,
              counter: false,
              formatters: [FilteringTextInputFormatter.digitsOnly],
            ),
          ),
        ]),
      ],
    );
  }
}