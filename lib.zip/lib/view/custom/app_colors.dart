import 'dart:ui';

class AppColors {
  // Hero
  static const tealA = Color(0xFF2F858C);
  static const tealB = Color(0xFF1B6670);
  static const tealC = Color(0xFF0E4A55);
  static const glow = Color(0x52F2D7A0); // #F2D7A0 @ 32%
  static const glowEnd = Color(0x00F2D7A0);

  // Garland / petals
  static const marigoldY = Color(0xFFF7C948);
  static const marigoldO = Color(0xFFF2A33A);
  static const marigoldCentre = Color(0xFFE07B1F);
  static const leaf = Color(0xFF5E9C61);
  static const sparkleCream = Color(0xFFFFF1C9);
  static const sparkleGold = Color(0xFFF2D7A0);

  // Lower area
  static const cream = Color(0xFFFBF6EE);
  static const headline = Color(0xFF15263D);
  static const forever = Color(0xFFA3520F);
  static const body = Color(0xFF4F5E72);
  static const link = Color(0xFF1F4E86);

  // Buttons
  static const btnA = Color(0xFF2C7F86);
  static const loginA = Color(0xFFFFF9F1);
  static const loginB = Color(0xFFF3DFC4);
  static const loginBorder = Color(0xFFE7C9A1);
  static const loginText = Color(0xFF7A4510);

  // Added for form fields
  static const fieldBorder = Color(0xFFCFDCEC);
  static const toggleBg = Color(0xFFF1E5D6);
  static const hint = Color(0xFF7A8594);
}